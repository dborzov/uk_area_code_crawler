UK Area code crawler: comments
-------------

We start with checking if there are any policy limits on crawlers or request frequency for that specific website by looking up the file `http://www.area-codes.org.uk/robots.txt`. It seems that in our case there is none.

The primary crawler is in `crawler.py`:

   python crawler.py

The script uses `requests` library, we may need to install it:

   pip install requests

There is a special case when for some area codes, the number of digits in the number varies. As no comment was given on how to treat these cases, the first mentioned of the possible options wat taken. For example, for the case:

    Local telephone numbers in Wigton are five or six digits long

the resultant line was

    016973,Wigton,5

Whenever something went wrong and we had a special case, the corresponding coment was written that contained the key word: 'Not found'.

These special cases are filtered out with filter_not_fixed.py:

    python filter_not_fixed.py

It yeilds only one special case: combined 016977 and 01697 area codes for the city of Brampton. Since it is only two cases I fixed them by hand.

More generally, the list of special cases can be addressed in the future and then introduced into the primary results with `joiner.py` script.

    python joiner.py

The final csv file is in out_final.csv